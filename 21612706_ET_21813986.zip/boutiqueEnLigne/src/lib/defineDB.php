<?php

// define("SERVER", "mysql.info.unicaen.fr");
// define("USER", "21612706");
// define("PASSWD", "phoo2co7Weeyueng");
// define("DB_NAME", "21612706_5");
//define("PORT", "5432");
//define("PDO_PGSQL_DSN", "mysql:dbname=" . DB_NAME .";host=" . SERVER . ";port=" . PORT . ";user=" . USER . ";password=" . PASSWD);

       define('DSN','mysql:dbname=21612706_5;host=mysql.info.unicaen.fr');// -u 21612706 -p 21612706_bd;port=3306;dbname=onlineshop_bd;charset=utf8';
       define('USER', '21612706');
       define('PASSWORD', 'phoo2co7Weeyueng');
       //$bd = new PDO($dsn, $user, $pass);
